PyQTermWidget
=============

Unlike the older pyqonsole this console widget works with PyQt4 and let's you
embed a shell into your application. 

See *docs/usage.rst* if you want to know how to use this widget. To test
the widget you can execute *demo.py*.

Or browse the generated HTML documentation at
http://pyqtermwidget.rtfd.org/

The vt100 terminal emulation code is based on AjaxTerm and WebShell.
All code is distributed under the General Public License 2.
